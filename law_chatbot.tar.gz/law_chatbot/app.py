import streamlit as st
import requests
import xml.etree.ElementTree as ET
import urllib.parse
import json
from datetime import datetime
import os
from openai import OpenAI

# 페이지 설정
st.set_page_config(
    page_title="법제처 AI 챗봇",
    page_icon="⚖️",
    layout="wide"
)

# 환경 변수 설정
LAW_API_KEY = "xNO+WmFJgOyLY2dN1qFw8M+R6uQ7Jdh8Ze6pK9+/tTLl6ZJybnY+UGCVIN0afOu/jiOvNS4P/Zx/zQZChed+jg=="
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# OpenAI 클라이언트 초기화
if OPENAI_API_KEY:
    client = OpenAI(api_key=OPENAI_API_KEY)
else:
    client = None
    st.warning("OpenAI API 키가 설정되지 않았습니다. AI 답변 기능이 제한됩니다.")

# 세션 상태 초기화
if "messages" not in st.session_state:
    st.session_state.messages = []

def search_law_data(query, num_rows=5):
    """법제처 API를 호출하여 법령 데이터를 검색합니다."""
    try:
        # API 키 URL 인코딩
        encoded_api_key = urllib.parse.quote_plus(LAW_API_KEY)
        
        # API 요청 URL 구성
        url = f"http://apis.data.go.kr/1170000/law/lawSearchList.do"
        params = {
            "serviceKey": encoded_api_key,
            "target": "law",
            "query": query,
            "numOfRows": num_rows,
            "pageNo": 1
        }
        
        # API 호출
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        # XML 파싱
        root = ET.fromstring(response.text)
        
        # 결과 파싱
        laws = []
        for law in root.findall('.//law'):
            law_info = {
                "법령명": law.find('법령명한글').text if law.find('법령명한글') is not None else "",
                "법령약칭명": law.find('법령약칭명').text if law.find('법령약칭명') is not None else "",
                "소관부처명": law.find('소관부처명').text if law.find('소관부처명') is not None else "",
                "법령구분명": law.find('법령구분명').text if law.find('법령구분명') is not None else "",
                "시행일자": law.find('시행일자').text if law.find('시행일자') is not None else "",
                "공포일자": law.find('공포일자').text if law.find('공포일자') is not None else "",
                "법령상세링크": law.find('법령상세링크').text if law.find('법령상세링크') is not None else ""
            }
            laws.append(law_info)
        
        return laws
    
    except Exception as e:
        st.error(f"법제처 API 호출 중 오류가 발생했습니다: {str(e)}")
        return []

def generate_ai_response(user_question, law_data):
    """OpenAI API를 사용하여 법령 데이터를 기반으로 답변을 생성합니다."""
    try:
        if not client:
            # OpenAI API가 없을 때 기본 답변 제공
            law_context = ""
            for i, law in enumerate(law_data, 1):
                law_context += f"{i}. {law['법령명']} ({law['법령구분명']})\n"
                law_context += f"   - 소관부처: {law['소관부처명']}\n"
                law_context += f"   - 시행일자: {law['시행일자']}\n"
                law_context += f"   - 공포일자: {law['공포일자']}\n\n"
            
            return f"""
**질문에 대한 답변:**

'{user_question}'에 대한 관련 법령 정보를 찾았습니다.

**관련 법령 목록:**
{law_context}

**참고사항:**
- 위 법령들은 귀하의 질문과 관련된 법령들입니다.
- 더 자세한 내용은 각 법령의 본문을 참조하시기 바랍니다.
- 정확한 법률 상담은 전문가에게 문의하시기 바랍니다.

*OpenAI API 키가 설정되지 않아 기본 답변을 제공합니다.*
"""
        
        # 법령 데이터를 텍스트로 변환
        law_context = ""
        for i, law in enumerate(law_data, 1):
            law_context += f"{i}. {law['법령명']} ({law['법령구분명']})\n"
            law_context += f"   - 소관부처: {law['소관부처명']}\n"
            law_context += f"   - 시행일자: {law['시행일자']}\n"
            law_context += f"   - 공포일자: {law['공포일자']}\n\n"
        
        # 프롬프트 구성
        prompt = f"""
당신은 대한민국의 법령 정보를 전문적으로 안내하는 AI 어시스턴트입니다.

사용자 질문: {user_question}

관련 법령 정보:
{law_context}

위의 법령 정보를 바탕으로 사용자의 질문에 대해 정확하고 도움이 되는 답변을 제공해주세요.
답변은 다음 형식으로 구성해주세요:

1. 질문에 대한 직접적인 답변
2. 관련 법령의 구체적인 내용 설명
3. 추가로 참고할 만한 정보나 주의사항

답변은 한국어로 작성하고, 법률 용어는 일반인이 이해하기 쉽게 설명해주세요.
"""
        
        # OpenAI API 호출
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "당신은 대한민국의 법령 정보를 전문적으로 안내하는 AI 어시스턴트입니다."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.7
        )
        
        return response.choices[0].message.content
    
    except Exception as e:
        st.error(f"AI 답변 생성 중 오류가 발생했습니다: {str(e)}")
        return "죄송합니다. 답변을 생성하는 중에 오류가 발생했습니다."

def save_conversation(user_question, ai_response, law_data):
    """대화 내용을 세션 상태에 저장합니다."""
    conversation = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "user_question": user_question,
        "ai_response": ai_response,
        "law_data": law_data
    }
    st.session_state.messages.append(conversation)

# 메인 UI
st.title("⚖️ 법제처 AI 챗봇")
st.markdown("---")

# 사이드바
with st.sidebar:
    st.header("📋 사용 안내")
    st.markdown("""
    이 챗봇은 법제처 Open API와 OpenAI를 활용하여 
    대한민국의 법령 정보에 대한 질문에 답변합니다.
    
    **사용 방법:**
    1. 아래 입력창에 법령 관련 질문을 입력하세요
    2. '질문하기' 버튼을 클릭하세요
    3. AI가 관련 법령을 검색하고 답변을 제공합니다
    
    **예시 질문:**
    - "근로기준법에 대해 알려주세요"
    - "개인정보보호법 관련 규정은?"
    - "교통법규 위반 시 처벌은?"
    """)
    
    if st.button("대화 기록 초기화"):
        st.session_state.messages = []
        st.success("대화 기록이 초기화되었습니다.")

# 메인 컨텐츠 영역
col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("💬 질문하기")
    
    # 사용자 입력
    user_input = st.text_area(
        "법령에 대한 질문을 입력하세요:",
        height=100,
        placeholder="예: 근로기준법에서 정하는 최대 근로시간은 얼마인가요?"
    )
    
    if st.button("🔍 질문하기", type="primary"):
        if user_input.strip():
            with st.spinner("법령 정보를 검색하고 답변을 생성하는 중..."):
                # 법제처 API 호출
                law_data = search_law_data(user_input)
                
                if law_data:
                    # AI 답변 생성
                    ai_response = generate_ai_response(user_input, law_data)
                    
                    # 대화 저장
                    save_conversation(user_input, ai_response, law_data)
                    
                    st.success("답변이 생성되었습니다!")
                else:
                    st.warning("관련 법령을 찾을 수 없습니다. 다른 키워드로 검색해보세요.")
        else:
            st.warning("질문을 입력해주세요.")

with col2:
    st.subheader("📊 검색 통계")
    st.metric("총 질문 수", len(st.session_state.messages))
    
    if st.session_state.messages:
        latest_msg = st.session_state.messages[-1]
        st.metric("마지막 질문 시간", latest_msg["timestamp"])

# 대화 기록 표시
st.markdown("---")
st.subheader("💭 대화 기록")

if st.session_state.messages:
    for i, msg in enumerate(reversed(st.session_state.messages)):
        with st.expander(f"질문 {len(st.session_state.messages) - i}: {msg['user_question'][:50]}..."):
            st.markdown(f"**🕐 시간:** {msg['timestamp']}")
            st.markdown(f"**❓ 질문:** {msg['user_question']}")
            st.markdown(f"**🤖 답변:** {msg['ai_response']}")
            
            if msg['law_data']:
                st.markdown("**📋 관련 법령:**")
                for j, law in enumerate(msg['law_data'], 1):
                    st.markdown(f"{j}. **{law['법령명']}** ({law['법령구분명']})")
                    st.markdown(f"   - 소관부처: {law['소관부처명']}")
                    st.markdown(f"   - 시행일자: {law['시행일자']}")
else:
    st.info("아직 질문이 없습니다. 위에서 질문을 입력해보세요!")

# 푸터
st.markdown("---")
st.markdown(
    """
    <div style='text-align: center; color: gray;'>
    <p>이 챗봇은 법제처 Open API와 OpenAI를 활용하여 개발되었습니다.</p>
    <p>제공되는 정보는 참고용이며, 정확한 법률 상담은 전문가에게 문의하시기 바랍니다.</p>
    </div>
    """,
    unsafe_allow_html=True
)

